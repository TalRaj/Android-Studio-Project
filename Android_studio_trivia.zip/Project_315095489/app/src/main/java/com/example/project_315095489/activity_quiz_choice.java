package com.example.project_315095489;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetManager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;

import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import Functions.QuizGenerator;
import Objects.genericQuestion;

public class activity_quiz_choice extends AppCompatActivity {
    Button highscores,entertainment,math,celebrities,animals,history,sports,geography,generalKnowledge,mythology,science,rules;
    String[] titles = {"Entertainment","Celebrities","Animals","History","Sports","Geography","General Knowledge","Mythology","Science"};
    Intent intent;
    final String MyPREFERENCES = "myPrefs";
    int size;
    String title;
    AlertDialog alert;
    AlertDialog.Builder builder;
    byte[] buffer;
    InputStream path;
    AssetManager am;
    final boolean[] selected = new boolean[3];
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_choice);
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            for (String key : extras.keySet()) {
                getIntent().removeExtra(key);
            }
        }

        highscores =(Button)findViewById(R.id.highscores);
        rules = (Button)findViewById(R.id.rules);
        entertainment = (Button)findViewById(R.id.entertainment);
        math = (Button)findViewById(R.id.math);
        celebrities = (Button)findViewById(R.id.celebrities);
        animals = (Button)findViewById(R.id.animals);
        history = (Button)findViewById(R.id.history);
        sports = (Button)findViewById(R.id.sports);
        geography = (Button)findViewById(R.id.geography);
        generalKnowledge = (Button)findViewById(R.id.generalKnowledge);
        mythology = (Button)findViewById(R.id.mythology);
        science = (Button)findViewById(R.id.science);
        Button[] btnList = {entertainment,celebrities,animals,history,sports,geography,generalKnowledge,mythology,science};
        am = this.getAssets();
        rules.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LayoutInflater inflater = (LayoutInflater)
                        getSystemService(LAYOUT_INFLATER_SERVICE);
                View popupView = inflater.inflate(R.layout.pop, null);

                // create the popup window
                int width = LinearLayout.LayoutParams.WRAP_CONTENT;
                int height = LinearLayout.LayoutParams.WRAP_CONTENT;
                boolean focusable = true; // lets taps outside the popup also dismiss it
                final PopupWindow popupWindow = new PopupWindow(popupView, width, height, focusable);

                // show the popup window
                // which view you pass in doesn't matter, it is only used for the window tolken
                popupWindow.showAtLocation(view, Gravity.CENTER, 0, 0);

                // dismiss the popup window when touched
                popupView.setOnTouchListener(new View.OnTouchListener() {
                    @Override
                    public boolean onTouch(View v, MotionEvent event) {
                        popupWindow.dismiss();
                        return true;
                    }
                });
            }
        });
        math.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String[] Arr = {getApplicationContext().getResources().getString(R.string.easy),getApplicationContext().getResources().getString(R.string.medium),getApplicationContext().getResources().getString(R.string.hard)};
                builder = new AlertDialog.Builder(activity_quiz_choice.this);
                builder.setTitle(getApplicationContext().getResources().getString(R.string.diffChoice));
                builder.setMultiChoiceItems(Arr, selected, new DialogInterface.OnMultiChoiceClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                        if(isChecked){
                            selected[which]= false;
                            ((AlertDialog) dialog).getListView().setItemChecked(which, false);
                            alert.dismiss();
                            goToMathQuiz(which+1,"Math");

                        }
                    }});
                builder.setCancelable(false);
                builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.setIcon(android.R.drawable.ic_dialog_alert);
                builder.create();
                alert = builder.create();
                alert.show();
            }
        });
        try {
            path = am.open("questions.json");
            size = path.available();
            buffer = new byte[size];
            path.read(buffer);
            path.close();
            Map<String, Map<String, ArrayList<Map<String,Object>>>> mapping = new ObjectMapper().readValue(buffer, HashMap.class);

            for(int i = 0;i<9;i++){
                int temp = i;
                btnList[i].setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        final String[] Arr = {getApplicationContext().getResources().getString(R.string.easy),getApplicationContext().getResources().getString(R.string.medium),getApplicationContext().getResources().getString(R.string.hard)};
                        builder = new AlertDialog.Builder(activity_quiz_choice.this);
                        builder.setTitle(getApplicationContext().getResources().getString(R.string.diffChoice));
                        builder.setMultiChoiceItems(Arr, selected, new DialogInterface.OnMultiChoiceClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which, boolean isChecked) {
                                if(isChecked){
                                    selected[which]= false;
                                    ((AlertDialog) dialog).getListView().setItemChecked(which, false);
                                    alert.dismiss();
                                    goToQuiz(which+1,titles[temp],mapping);
                                }
                            }});
                        builder.setCancelable(false);
                        builder.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                            }
                        });
                        builder.setIcon(android.R.drawable.ic_dialog_alert);
                        builder.create();
                        alert = builder.create();
                        alert.show();
                    }
                    });
                }

        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        highscores.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(),activity_highscores.class);
                startActivity(intent);
                finish();
            }
        });
    }

    private void goToQuiz(int difficulty,String type,Map<String, Map<String, ArrayList<Map<String,Object>>>> mapping){
        intent = null;
        List<genericQuestion<String>> Questions = new ArrayList<>();
        Questions = new QuizGenerator().stringQuiz(difficulty,type,mapping);
        if(Questions.get(0).getInCorrect().size()==1){
            intent = new Intent(this,activity_boolean.class);
        }
        else{
            intent = new Intent(this,activity_four_options.class);
        }
        intent.putExtra("questions",((ArrayList<genericQuestion<String>>)Questions));
        intent.putExtra("questionNum", 0);
        SharedPreferences sharedpreferences =  getApplicationContext().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sharedpreferences.edit();
        edit.putInt("currentDifficulty" , difficulty);
        edit.putString("currentTitle", type);
        edit.commit();
        startActivity(intent);
        finish();

    }
    private void goToMathQuiz(int difficulty,String title){
        List<Object> Questions2 = new ArrayList<>();
        intent = null;
        Questions2 = new QuizGenerator().mathQuiz(difficulty);
        intent = new Intent(activity_quiz_choice.this,activity_math.class);
        intent.putExtra("questions",((ArrayList<Object>)Questions2));
        intent.putExtra("questionNum", 0);
        SharedPreferences sharedpreferences =  getApplicationContext().getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        SharedPreferences.Editor edit = sharedpreferences.edit();
        edit.putInt("currentDifficulty" , difficulty);
        edit.putString("currentTitle", title);
        edit.commit();
        startActivity(intent);
        finish();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        intent = new Intent(this,activity_login.class);
        startActivity(intent);
        finish();
    }
}