package com.example.project_315095489;

import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Objects.genericQuestion;

public class activity_math extends AppCompatActivity {
    Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9,done,dot,clear,plusminus;
    TextView question,QuestionNum,timer;
    EditText answer;
    int questionNum,time;
    CountDownTimer counter;
    Double score;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_math);
        btn0 = (Button)findViewById(R.id.button0);
        btn1 = (Button)findViewById(R.id.button1);
        btn2 = (Button)findViewById(R.id.button2);
        btn3 = (Button)findViewById(R.id.button3);
        btn4 = (Button)findViewById(R.id.button4);
        btn5 = (Button)findViewById(R.id.button5);
        btn6 = (Button)findViewById(R.id.button6);
        btn7 = (Button)findViewById(R.id.button7);
        btn8 = (Button)findViewById(R.id.button8);
        btn9 = (Button)findViewById(R.id.button9);
        plusminus =(Button)findViewById(R.id.plusminus);
        dot = (Button)findViewById(R.id.button_dot);
        clear = (Button)findViewById(R.id.button_clear);
        done = (Button)findViewById(R.id.done);
        question = (TextView)findViewById(R.id.questionTxt);
        QuestionNum = (TextView)findViewById(R.id.questionNum);
        timer =(TextView)findViewById(R.id.timer);
        answer = (EditText)findViewById(R.id.result);
        Button[] btnList = {btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7,btn8,btn9};

        Bundle extras = getIntent().getExtras();
        questionNum = extras.getInt("questionNum");
        List<genericQuestion<Object>> questions = (List<genericQuestion<Object>>) extras.get("questions");
        genericQuestion<Object> questionInfo = questions.get(questionNum);
        score = extras.getDouble("score",0.0);
        QuestionNum.setText(this.getResources().getString(R.string.questionNum)+" "+questionNum);
        question.setText(questionInfo.getQuestion());
        counter = new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {
                timer.setText(millisUntilFinished / 1000 +" "+ getApplicationContext().getResources().getString(R.string.seconds));
                time = (int)millisUntilFinished / 1000;
            }

            public void onFinish() {
                try{
                        Toast.makeText(getApplicationContext(),"Too long",Toast.LENGTH_LONG).show();
                        if(questionNum == 9){
                            intent = new Intent(getApplicationContext(), activity_finish.class);
                            intent.putExtra("score",score);
                            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        }
                        else {
                            intent = new Intent(getApplicationContext(), activity_math.class);
                            intent.putExtra("questions", (ArrayList<genericQuestion<Object>>) questions);
                            intent.putExtra("score", score);
                            intent.putExtra("questionNum", questionNum + 1);
                        }
                    startActivity(intent);
                    finish();
                }


                catch (Exception exception){
                    Toast.makeText(getApplicationContext(),"Illegal Input",Toast.LENGTH_LONG).show();
                }
            }
        }.start();
        for(int i=0;i<10;i++){
            String temp = Integer.toString(i);
            btnList[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    answer.append(temp);
                }
            });
        }
        plusminus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(answer.getText().toString().startsWith("-")){
                    answer.setText(answer.getText().toString().substring(1));
                }
                else{
                    answer.setText("-" + answer.getText());
                }
            }
        });
        dot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.append(".");
            }
        });
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                answer.setText("");
            }
        });
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try{
                    String check = answer.getText().toString();
                    String check2 = check + ".0";
                    if(check.equals(String.valueOf(questionInfo.getAnswer())) || check2.equals(String.valueOf(questionInfo.getAnswer())) ){
                        Toast.makeText(getApplicationContext(),"Correct",Toast.LENGTH_LONG).show();
                        if(questionNum == 9){
                            intent = new Intent(getApplicationContext(), activity_finish.class);
                            intent.putExtra("score",score+questionInfo.finalPoints(time));
                            intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        }
                        else {
                            intent = new Intent(getApplicationContext(), activity_math.class);
                            intent.putExtra("questions", (ArrayList<genericQuestion<Object>>) questions);
                            intent.putExtra("questionNum", questionNum + 1);
                            Log.i("Select", timer.getText().toString());
                            intent.putExtra("score", score + questionInfo.finalPoints(time));
                        }
                        counter.cancel();
                        startActivity(intent);
                        finish();
                    }
                    else{
                        Toast.makeText(getApplicationContext(),"Incorrect",Toast.LENGTH_LONG).show();
                    }
                }
                catch (Exception exception){
                    Toast.makeText(getApplicationContext(),"Illegal Input",Toast.LENGTH_LONG).show();
                }
            }
        });


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        counter.cancel();
        intent = new Intent(this,activity_quiz_choice.class);
        startActivity(intent);
        finish();
    }
}