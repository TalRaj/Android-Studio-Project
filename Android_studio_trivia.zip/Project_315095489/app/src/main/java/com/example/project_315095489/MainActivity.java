package com.example.project_315095489;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import Objects.LanguageManager;


public class MainActivity extends AppCompatActivity {

    Button Hebrew,English;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Bundle extras = getIntent().getExtras();
        intent = new Intent(this,activity_login.class);

        LanguageManager lang = new LanguageManager(this);
        Hebrew = findViewById(R.id.heb);
        English = findViewById(R.id.eng);


        Hebrew.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                lang.updateResource("iw");
                recreate();
                startActivity(intent);
                finish();
            }
        });
        English.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                lang.updateResource("en");
                recreate();
                startActivity(intent);
                finish();
            }
        });
        if(extras != null){
            Hebrew.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    lang.updateResource("iw");
                    String caller   = getIntent().getStringExtra("caller");
                    Log.i("Select",caller + " am in place");
                    try {
                        Log.i("Select", " rregregre");
                        Class callerClass = Class.forName(getPackageName() +"."+caller);
                        Log.i("Select",callerClass+ " rregregre");
                        intent = new Intent(getApplicationContext(),callerClass);
                        startActivity(intent);
                        finish();
                    }
                    catch(Exception E){
                        Log.i("Select","caller class problematic");
                        Log.i("Select",E.toString());
                        finish();}
                }
            });
            English.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View view) {
                    lang.updateResource("en");
                    String caller   = getIntent().getStringExtra("caller");
                    Log.i("Select",caller + " am in place");
                    try {
                        Class callerClass = Class.forName(getPackageName() +"."+caller);
                        Log.i("Select",callerClass + " am in place");
                        intent = new Intent(getApplicationContext(),callerClass);
                        startActivity(intent);
                        finish();
                    }
                    catch(Exception E){
                        Log.i("Select","caller class problematic");
                        Log.i("Select",E.toString());
                        finish();
                    }
                }
            });
        }
        }
    }
