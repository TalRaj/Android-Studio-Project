package com.example.project_315095489;


import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import Objects.genericQuestion;

public class activity_boolean extends AppCompatActivity {
    Button yes,no;
    TextView question,questionNum,timer;
    Intent intent;
    int time,questionN;
    Double score;
    CountDownTimer counter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boolean);
        Bundle extras = getIntent().getExtras();
        questionN = extras.getInt("questionNum");
        score = extras.getDouble("score");
        List<genericQuestion<String>> questions = (List<genericQuestion<String>>) extras.get("questions");
        genericQuestion<String> questionInfo = questions.get(questionN);
        Log.i("Select",questionInfo.toString());
        yes = (Button)findViewById(R.id.yes);
        no = (Button)findViewById(R.id.no);
        timer =(TextView)findViewById(R.id.timer);
        question = (TextView)findViewById(R.id.questionTxt);
        questionNum = (TextView)findViewById(R.id.questionNum);
        questionNum.setText(this.getResources().getString(R.string.questionNum) +" " +questionN);
        question.setText(questionInfo.getQuestion().replace("&amp;","&").replace("&quot;","'").replace("&#039;","'"));
        counter = new CountDownTimer(60000, 1000) {

            public void onTick(long millisUntilFinished) {
                timer.setText(millisUntilFinished / 1000 + getApplicationContext().getResources().getString(R.string.seconds));
                time = (int)millisUntilFinished / 1000;
            }

            public void onFinish() {
                try{

                    Toast.makeText(getApplicationContext(),"Too long",Toast.LENGTH_LONG).show();
                    if(questionN == 9){
                        intent = new Intent(getApplicationContext(), activity_finish.class);
                        intent.putExtra("score",score);
                        startActivity(intent);
                        finish();
                    }
                    else {
                        if (questions.get(questionN + 1).getInCorrect().size() == 1) {
                            intent = new Intent(getApplicationContext(), activity_boolean.class);
                        } else {
                            intent = new Intent(getApplicationContext(), activity_four_options.class);
                        }
                        intent.putExtra("questions", (ArrayList<genericQuestion<String>>) questions);
                        intent.putExtra("score", score);
                        intent.putExtra("questionNum", questionN + 1);
                        counter.cancel();
                        startActivity(intent);
                        finish();
                    }
                }


                catch (Exception exception){
                    Toast.makeText(getApplicationContext(),"Illegal Input",Toast.LENGTH_LONG).show();
                }
            }
        }.start();
        yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Incorrect", Toast.LENGTH_LONG).show();
                if(questionN == 9){
                    intent = new Intent(getApplicationContext(), activity_finish.class);
                    intent.putExtra("score",score);
                    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    counter.cancel();
                    startActivity(intent);
                    finish();
                }
                else {
                    if (questions.get(questionN + 1).getInCorrect().size() == 1) {
                        intent = new Intent(getApplicationContext(), activity_boolean.class);
                    } else {
                        intent = new Intent(getApplicationContext(), activity_four_options.class);
                    }
                    intent.putExtra("questions", (ArrayList<genericQuestion<String>>) questions);
                    intent.putExtra("score", score);
                    intent.putExtra("questionNum", questionN + 1);
                    counter.cancel();
                    startActivity(intent);
                    finish();
                }
            }
        });
        no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "Incorrect", Toast.LENGTH_LONG).show();
                if(questionN == 9){
                    intent = new Intent(getApplicationContext(), activity_finish.class);
                    intent.putExtra("score",score);
                    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    counter.cancel();
                    startActivity(intent);
                    finish();
                }
                else{
                    if(questions.get(questionN+1).getInCorrect().size() == 1){
                        intent = new Intent(getApplicationContext(),activity_boolean.class);
                    }
                    else{
                    intent = new Intent(getApplicationContext(),activity_four_options.class);
                    }
                    intent.putExtra("questions",(ArrayList<genericQuestion<String>>)questions);
                    intent.putExtra("score",score);
                    intent.putExtra("questionNum", questionN+1);
                    counter.cancel();
                    startActivity(intent);
                    finish();
                }
            }
        });
        if(questionInfo.getAnswer().equals("True")){
            yes.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_LONG).show();
                    if(questionN == 9){
                        intent = new Intent(getApplicationContext(), activity_finish.class);
                        intent.putExtra("score",score+questionInfo.finalPoints(time));
                        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        counter.cancel();
                        startActivity(intent);
                        finish();
                    }
                    else{
                        if (questions.get(questionN + 1).getInCorrect().size() == 1) {
                            intent = new Intent(getApplicationContext(), activity_boolean.class);
                        }
                        else {
                            intent = new Intent(getApplicationContext(), activity_four_options.class);
                        }
                        intent.putExtra("questions", (ArrayList<genericQuestion<String>>) questions);
                        intent.putExtra("questionNum", questionN + 1);
                        intent.putExtra("score",score+questionInfo.finalPoints(time));
                        startActivity(intent);
                        counter.cancel();
                        finish();
                    }
                }
            });
        }

        else{
            no.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_LONG).show();
                    if(questionN == 9){
                        intent = new Intent(getApplicationContext(), activity_finish.class);
                        intent.putExtra("score",score+questionInfo.finalPoints(time));
                        intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                        counter.cancel();
                        startActivity(intent);
                        finish();
                    }
                    else{
                        if (questions.get(questionN + 1).getInCorrect().size() == 1) {
                            intent = new Intent(getApplicationContext(), activity_boolean.class);
                        }
                        else {
                            intent = new Intent(getApplicationContext(), activity_four_options.class);
                        }
                        intent.putExtra("questions", (ArrayList<genericQuestion<String>>) questions);
                        intent.putExtra("questionNum", questionN + 1);
                        intent.putExtra("score",score+questionInfo.finalPoints(time));
                        counter.cancel();
                        startActivity(intent);
                        finish();
                    }
                }
            });
        }


    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        counter.cancel();
        intent = new Intent(this,activity_quiz_choice.class);
        startActivity(intent);
        finish();
    }
}