package com.example.project_315095489;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import Functions.dataManager;
import Objects.CustomAdapter;
import Objects.User;
import Objects.listOfThree;

public class activity_highscores extends AppCompatActivity {
    ArrayList<User> users;
    Button back;
    ListView scores;
    Intent intent;
    String easy,medium,hard,name;
    SharedPreferences sharedPreferences;
    HashMap<Integer,String> dict = new HashMap<>();
    final String MyPREFERENCES = "myPrefs";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_highscores);

        sharedPreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        name = sharedPreferences.getString("currentPlayer",null);
        users = new dataManager(this).loadData();
        back =(Button)findViewById(R.id.back);
        scores = (ListView)findViewById(R.id.scores);
        easy = this.getResources().getString(R.string.easy);
        medium = this.getResources().getString(R.string.medium);
        hard = this.getResources().getString(R.string.hard);
        dict.put(1,easy);
        dict.put(2,medium);
        dict.put(3,hard);
        dict.put(0,"wrong");

        List<listOfThree> people = new ArrayList<>();

        for(User i:users){
            if(!i.getScores().keySet().isEmpty()) {
                people.add(new listOfThree(i.getName(),"",""));
                for (String title : i.getScores().keySet()) {
                    people.add(new listOfThree(title, "", ""));
                    for (String diff : i.getScores().get(title).keySet()) {
                        people.add(new listOfThree(diff, i.getScores().get(title).get(diff).toString(), ""));
                    }
                }
            }
        }

        CustomAdapter CA = new CustomAdapter(this,people);
        scores.setAdapter(CA);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(),activity_quiz_choice.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        intent = new Intent(this,activity_quiz_choice.class);
        startActivity(intent);
        finish();
    }
}