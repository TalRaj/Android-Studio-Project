package com.example.project_315095489;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import Functions.dataManager;
import Objects.CustomAdapter;
import Objects.User;
import Objects.listOfThree;

public class activity_finish extends AppCompatActivity {
    ArrayList<User> users;
    Button back;
    ListView scores;
    Double score;
    Intent intent;
    String easy,medium,hard,name,difficulty,title;
    SharedPreferences sharedPreferences;
    HashMap<Integer,String> dict = new HashMap<>();
    final String MyPREFERENCES = "myPrefs";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);
        Bundle extras = getIntent().getExtras();
        score =(double) Math.round(extras.getDouble("score")* 10d) / 10d;
        sharedPreferences = getSharedPreferences(MyPREFERENCES, Context.MODE_PRIVATE);
        name = sharedPreferences.getString("currentPlayer",null);
        users = new dataManager(this).loadData();
        back =(Button)findViewById(R.id.back);
        scores = (ListView)findViewById(R.id.scores);
        easy = this.getResources().getString(R.string.easy);
        medium = this.getResources().getString(R.string.medium);
        hard = this.getResources().getString(R.string.hard);
        dict.put(1,easy);
        dict.put(2,medium);
        dict.put(3,hard);
        dict.put(0,"wrong");
        title = sharedPreferences.getString("currentTitle","wrong");
        difficulty = dict.get(sharedPreferences.getInt("currentDifficulty",0));
        Log.i("Select",difficulty + sharedPreferences.getInt("currentDifficulty",0) +", " +name+score);
        List<listOfThree> people = new ArrayList<>();
        people.add(new listOfThree(name,difficulty,score.toString()));

        for(User i:users){
            if(i.getScores().containsKey(title)){
                if(i.getScores().get(title).containsKey(difficulty) && name.equals(i.getName()) && score >= i.getScores().get(title).get(difficulty)){
                    i.getScores().get(title).remove(difficulty);
                }
                for(String diff:i.getScores().get(title).keySet()){
                    people.add(new listOfThree(i.getName(),diff,i.getScores().get(title).get(diff).toString()));
                }


            }
            if(name.equals(i.getName())){
                i.addHighScore(difficulty,title,score);
            }
        }
        new dataManager(this).saveData(users);
        people.add(new listOfThree("carmel",medium,"31"));
        people.add(new listOfThree("rahim",hard,"15"));
        CustomAdapter CA = new CustomAdapter(this,people);
        scores.setAdapter(CA);
        try {
            AssetFileDescriptor afd = getAssets().openFd("yay.mp3");
            MediaPlayer player = new MediaPlayer();
            player.setDataSource(afd.getFileDescriptor(), afd.getStartOffset(), afd.getLength());
            player.prepare();
            player.start();
        }
        catch (Exception e){
            Log.i("Select","Didnt work");
        }
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(),activity_quiz_choice.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        intent = new Intent(this,activity_quiz_choice.class);
        startActivity(intent);
        finish();
    }
}