package Functions;




import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Random;
import Objects.genericQuestion;

public class QuizGenerator {
    private Random rand;
    private String json = "";


    // quiz makers
    public List<genericQuestion<String>> stringQuiz(int difficulty,String type, Map<String, Map<String, ArrayList<Map<String,Object>>>> questionMap){
        int easy,medium,hard,questionsInJson;
        List<genericQuestion<String>> Quiz = new ArrayList<>();
        rand = new Random();
        List<Integer> randList;
        if(difficulty == 1){
            easy = rand.nextInt(3) + 5;
            hard = rand.nextInt(3);
            medium = 10 - easy - hard;
        }
        else if(difficulty == 2){
            easy = rand.nextInt(3);
            medium = rand.nextInt(3) + 5;
            hard = 10 - easy - medium;
        }
        else{
            medium = rand.nextInt(3);
            hard = rand.nextInt(3) + 5;
            easy = 10 - hard - medium;
        }
        questionsInJson = questionMap.get(type).get("easy").size();
        randList = randList(easy,questionsInJson);
        for(int i = 0;i<easy;i++){
            String Q = questionMap.get(type).get("easy").get(randList.get(i)).get("Question").toString(); //Question map is json type, its stored in questions.json
            String T = questionMap.get(type).get("easy").get(randList.get(i)).get("Correct").toString();
            ArrayList<String> F = new ArrayList((List)questionMap.get(type).get("easy").get(randList.get(i)).get("Incorrect"));
            Quiz.add(new genericQuestion<String>(T,1,Q,F));
        }
        questionsInJson = questionMap.get(type).get("medium").size();
        randList = randList(medium,questionsInJson);
        for(int i = 0;i<medium;i++){
            String Q = questionMap.get(type).get("medium").get(randList.get(i)).get("Question").toString();
            String T = questionMap.get(type).get("medium").get(randList.get(i)).get("Correct").toString();
            ArrayList<String> F = new ArrayList((List)questionMap.get(type).get("medium").get(randList.get(i)).get("Incorrect"));
            Quiz.add(new genericQuestion<String>(T,2,Q,F));
        }
        questionsInJson = questionMap.get(type).get("hard").size();
        randList = randList(hard,questionsInJson);
        for(int i = 0;i<hard;i++){
            String Q = questionMap.get(type).get("hard").get(randList.get(i)).get("Question").toString();
            String T = questionMap.get(type).get("hard").get(randList.get(i)).get("Correct").toString();
            ArrayList<String> F = new ArrayList((List)questionMap.get(type).get("hard").get(randList.get(i)).get("Incorrect"));
            Quiz.add(new genericQuestion<String>(T,3,Q,F));
        }

        return Quiz;
    } //string/boolean quiz from json

    public List<Object> mathQuiz(int difficulty){ // make a math quiz
        int easy, medium, hard, questionType, X, Y, T, type, A1, d, q, N; // Questiontype is used to determine later questions, X,Y are the numbers we calc, T is the answer, type is for series questions, A1,d, q and N are also for series questions
        String Q; // question
        Double R; // for inf geometric
        List<Object> Quiz = new ArrayList<>();
        rand = new Random();
        if(difficulty == 1){
            easy = rand.nextInt(3) + 5;
            hard = rand.nextInt(3);
            medium = 10 - easy - hard;
        }
        else if(difficulty == 2){
            easy = rand.nextInt(3);
            medium = rand.nextInt(3) + 5;
            hard = 10 - easy - medium;
        }
        else{
            medium = rand.nextInt(3);
            hard = rand.nextInt(3) + 5;
            easy = 10 - hard - medium;
        }
        for(int i = 0;i<easy;i++){
            questionType = rand.nextInt(4); // 0 is +, 1 is -, 2 is *, 3 is /
            if(questionType == 0){
                X = rand.nextInt(401) - 200;
                Y = rand.nextInt(401) - 200;
                T = X + Y;
                Q = X + " + " + Y + " =?";
            }
           else if(questionType == 1){
                X = rand.nextInt(400) - 200;
                Y = rand.nextInt(400) - 200;
                T = X - Y;
                Q = X + " - " + Y + " =?";
            }
            else if(questionType == 2){
                X = rand.nextInt(11);
                if(X == 0){X =1;}
                Y = rand.nextInt((100 / X)+1);
                T = X * Y;
                Q = X + " X " + Y + " =?";
            }
            else{
                X = rand.nextInt(11);
                if(X == 0){X =1;}
                T = rand.nextInt( (100/X)+1);
                Y = X * T;
                Q = Y + " / " + X + " =?";
            }
            Quiz.add(new genericQuestion<Integer>(T,1,Q));
        }
        for(int i = 0;i<medium;i++){
            questionType = rand.nextInt(4); // 0 is *, 1 is /, 2 is ^, 3 is sqrt
            if(questionType == 0){
                int Xr = rand.nextInt(10) +1;
                int Xl = rand.nextInt(41)-20;
                String s = Xl+"."+Xr;
                Double Xf = Double.parseDouble(s);
                if(Xf == 0.0){Xf = 1.0;}
                Y = rand.nextInt(41) - 20;
                Double Tf = Xf * Y;
                Tf = (double) Math.round(Tf * 10d) / 10d;
                Q = Y + " * " + Xf + " =?";
                Quiz.add(new genericQuestion<Double>(Tf,2,Q));
            }
            else if(questionType == 1){
                int Xr = rand.nextInt(10) +1;
                int Xl = rand.nextInt(41)-20;
                String s = Xl+"."+Xr;
                Double Xf = Double.parseDouble(s);
                Double Tf = new Double(rand.nextInt(41)-20);
                Tf = (double) Math.round(Tf * 10d) / 10d;
                Double Yf = Tf * Xf;
                Yf = (double) Math.round(Yf * 10d) / 10d;
                Q = Yf + " / " + Xf + " =?";
                Quiz.add(new genericQuestion<Double>(Tf,2,Q));
            }
            else if(questionType == 2){
                X = rand.nextInt(31) - 15;
                Y = rand.nextInt(2)+2;
                T = (int)Math.pow(X , Y);
                Q = X + " ^ " + Y + " =?";
                Quiz.add(new genericQuestion<Integer>(T,2,Q));
            }
            else{
                T = rand.nextInt(31) - 15;
                Y = rand.nextInt(2)+2;
                X = (int)Math.pow(T , Y);
                Q = Y + "√" + X + " =?";
                Quiz.add(new genericQuestion<Integer>(T,2,Q));
            }
        }
        for(int i = 0;i<hard;i++){
            type = rand.nextInt(3); // 0 is arithmetic, 1 is geometric, 2 is infinite collapsing
            List<Object> info = randSeries(type);
            if(type == 0){
                A1 = (int)info.get(0);
                N = (int)info.get(1);
                d = (int)info.get(2);
                T = (N * ( 2*A1 + (N-1) * d )) / 2;
                Q = "Let there be an arithmetic sequence A, where A1 is "+ A1 + ", There are " + N +" terms in A\n" +
                        "and the common difference is equal to "+d+", find the sum of A";
                Quiz.add(new genericQuestion<Integer>(T,3,Q));
            }
            else if(type == 1){
                A1 = (int)info.get(0);
                N = (int)info.get(1);
                q = (int)info.get(2);
                T = A1 * ( (1 - (int)Math.pow(q,N)) / (1-q) );
                Q = "Let there be a geometric sequence B, where B1 is "+ A1 + ", There are " + N +" terms in B\n" +
                        "and the common ratio is equal to "+q+", find the sum of B,Rounded to 1 decimal place";
                Quiz.add(new genericQuestion<Integer>(T,3,Q));
            }
            else{
                A1 = (int)info.get(0);
                R = (Double)info.get(2);
                Double Tf = new Double(A1 / (1- R ));
                Tf = (double) Math.round(Tf * 10d) / 10d;
                Q = "Let there be an infinite geometric sequence C, where C1 is "+ A1 + "\n" +
                        "and the common ratio is equal to "+ R +", find the sum of C,Rounded to 1 decimal place";
                Quiz.add(new genericQuestion<Double>(Tf,3,Q));
            }
        }
        return Quiz;
    } //mathematical quiz generated randomly


    //helper functions
    public List<Integer> randList(int amount,int range) {
        List<Integer> list = new ArrayList<>();
        for (int i=0; i<range; i++) list.add(i);
        Collections.shuffle(list);
        return list.subList(0,amount+1);
    } // list with random numbers

    public List<Object> randSeries(int type){
        List<Object> list = new ArrayList<>();
        Double Q;
        int A1,N,d,q; // A1 - first num, N - total items if not infinite, q - difference in geometric/infinite, d - distance in arithmetic
        // type - 0 is arithmetic, 1 is geometric, 2 is infinite collapsing
        if(type == 0){
            A1 = rand.nextInt(11);
            N = rand.nextInt(96)+5;
            d = rand.nextInt(51);
            list.add(A1);
            list.add(N);
            list.add(d);
        }
        else if(type == 1){
            A1 = rand.nextInt(10)+1;
            N = rand.nextInt(3)+2;
            q = rand.nextInt(4)+2;
            list.add(A1);
            list.add(N);
            list.add(q);
        }
        else{
            A1 = rand.nextInt(10001);
            N = 101; // since no other series could be of length 101, we use it as standby for infinite
            q = rand.nextInt(11)+1;
            String s = "0."+q;
            Q = Double.parseDouble(s);
            if(Q == 0.0){Q = 0.1;}
            if(rand.nextInt(2) ==1){Q = -Q;}
            Q = (double) Math.round(Q * 10d) / 10d;
            list.add(A1);
            list.add(N);
            list.add(Q);
        }
        return list;
    } // random sequence of varying types
}
