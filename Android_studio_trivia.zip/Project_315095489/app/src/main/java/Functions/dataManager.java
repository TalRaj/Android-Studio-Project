package Functions;

import android.content.Context;
import android.content.SharedPreferences;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import java.util.ArrayList;
import Objects.User;

public class dataManager {
    final String prefs = "myPrefs";
    Context ct;
    public dataManager(Context ct){
        this.ct = ct;
    }
    public void saveData(ArrayList<User> list){
        SharedPreferences sharedPreferences = ct.getSharedPreferences(prefs,Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        Gson gson = new Gson();
        String json = gson.toJson(list);
        editor.putString("Users",json);
        editor.commit();
    }
    public ArrayList<User> loadData(){
        SharedPreferences sharedPreferences = ct.getSharedPreferences(prefs,Context.MODE_PRIVATE);
        Gson gson = new Gson();
        String json = sharedPreferences.getString("Users",null);
        Type type =  new TypeToken<ArrayList<User>>() {}.getType();
        ArrayList<User> list = gson.fromJson(json,type);
        if(list == null || list.isEmpty()){
            list = new ArrayList<>();
        }
        return list;
    }

}
