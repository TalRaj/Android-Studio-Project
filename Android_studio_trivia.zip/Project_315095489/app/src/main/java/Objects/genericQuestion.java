package Objects;


import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

/**
 *non specific question
 */

public class genericQuestion<T> implements QuestionType, Serializable {
    protected T answer;
    protected int difficulty;
    protected String question;
    private List<T> inCorrect;

    public genericQuestion(@NonNull T answer,@NonNull int difficulty,@NonNull String question,@NonNull ArrayList<T> inCorrect) {
        this.answer = answer;
        this.difficulty = difficulty;
        this.question = question;
        this.inCorrect = new ArrayList<T>();
        for(int i = 0;i< inCorrect.size();i++){this.inCorrect.add(null);}
        Collections.copy(this.inCorrect,inCorrect);
    }
    public genericQuestion() {
        this.answer = null;
        this.difficulty = 0;
        this.question = null;
        this.inCorrect = new ArrayList<>();
    }
    public genericQuestion(@NonNull T answer,@NonNull int difficulty,@NonNull String question) {
        this.answer = answer;
        this.difficulty = difficulty;
        this.question = question;
        this.inCorrect  = new ArrayList<T>();
    }
    public genericQuestion(@NonNull genericQuestion<T> question) {
        this.answer = question.getAnswer();
        this.difficulty = question.getDifficulty();
        this.question = question.getQuestion();
        this.inCorrect = new ArrayList<T>();
        for(int i = 0;i< question.getInCorrect().size();i++){this.inCorrect.add(null);}
        Collections.copy(this.inCorrect,question.getInCorrect());
    }
    public List<T> getInCorrect() {
        return inCorrect;
    }

    @Override
    public Boolean isCorrectAnswer(Object answer) {
        try{
            T obj = (T)answer;
            return this.answer.equals(obj);
        }
        catch (Exception e){
            return false;
        }

    }

    @Override
    public Double finalPoints(@NonNull int timeLeft) {
        int points = 10 * difficulty;
        Double timeCost = (timeLeft*1.0) / 60;
        return new Double(points * timeCost);
    }

    public T getAnswer() {
        return answer;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public String getQuestion(){
        return question;
    }



    @Override
    public int hashCode() {
        return Objects.hash(getAnswer(),getDifficulty(),getQuestion());
    }

    @Override
    public boolean equals(@Nullable Object obj) {
        if (this == obj) return true;
        if ((obj == null) || !(obj instanceof genericQuestion)) return false;
        genericQuestion<T> q1 = (genericQuestion<T>) obj;
        if (this.question.equals(q1.getQuestion())) return true;
        return false;
    }

    @Override
    public String toString() {
        return "question='" + question +
                ", answer=" + answer +
                ", difficulty=" + difficulty +
                ", inCorrect=" + inCorrect.toString()+
                '}';
    }
}

