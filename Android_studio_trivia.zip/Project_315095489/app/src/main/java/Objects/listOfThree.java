package Objects;

public class listOfThree {
    private String first;
    private String second;
    private String third;

    public listOfThree(String first, String second,String third) {
        this.first = first;
        this.second = second;
        this.third = third;
    }

    public String getFirst() {
        return first;
    }

    public String getSecond() {
        return second;
    }
    public String getThird() {
        return third;
    }
}
