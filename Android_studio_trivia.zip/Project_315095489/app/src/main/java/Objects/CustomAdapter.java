package Objects;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import com.example.project_315095489.R;
import java.util.List;

public class CustomAdapter extends ArrayAdapter<listOfThree>
{
    public CustomAdapter(Context context, List<listOfThree> strings)
    {
        super(context, 0, strings);
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent)
    {
        LayoutInflater inflater = (LayoutInflater) getContext()
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View rowView = inflater.inflate(R.layout.list_item, parent, false);
        listOfThree info = (listOfThree) getItem(position);
        TextView name = (TextView) rowView.findViewById(R.id.name);
        TextView difficulty = (TextView) rowView.findViewById(R.id.difficulty);
        TextView score = (TextView) rowView.findViewById(R.id.score);

        name.setText(info.getFirst());
        difficulty.setText(info.getSecond());
        score.setText(info.getThird());
        return rowView;
    }
}
