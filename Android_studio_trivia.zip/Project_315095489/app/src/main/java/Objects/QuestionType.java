package Objects;

import android.support.annotation.NonNull;

/**
 * interface defining a generic question
 */
public interface QuestionType{
    Boolean isCorrectAnswer(Object answer);
    Double finalPoints(@NonNull int timeCost);

}
