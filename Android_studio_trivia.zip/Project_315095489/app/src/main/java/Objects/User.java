package Objects;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import java.util.HashMap;
import java.util.Objects;
import java.util.Set;

/**
 * Class for users
 * we dont validate name beacuse we validate it upon login
 */

public class User {
    private String Name;
    private HashMap<String,HashMap<String,Double>> Scores;

    public User(String Name,@NonNull HashMap<String,HashMap<String,Double>> Scores) {
        this.Name = Name;
        this.Scores = Scores;
    }

    public User(String Name) {
        this.Name = Name;
        Scores = new HashMap<>();
    }

    @Override
    public int hashCode() {
        return Objects.hash(Name,Scores);
    }

    public String getName() {
        return Name;
    }

    public HashMap<String, HashMap<String, Double>> getScores() {
        return Scores;
    }

    public void addHighScore(String difficulty,String title, Double score) {
        if(Scores.containsKey(title) && Scores.get(title).containsKey(difficulty)){
            if(Scores.get(title).get(difficulty) < score){
                Scores.get(title).put(difficulty,score);
            }
        }
        else if(Scores.containsKey(title) && !Scores.get(title).containsKey(difficulty)){
            Scores.get(title).put(difficulty,score);
        }
        else{
            HashMap<String,Double> temp = new HashMap<>();
            temp.put(difficulty,score);
            Scores.put(title,temp);
        }
    }

    public HashMap<String,Double> getTitleScores(@NonNull String title){
        try{
            return this.getScores().get(title);
        }
        catch (Exception E){
            return null;
        }
    }
    @Override
    public boolean equals(@Nullable Object obj) {
        if (this == obj) return true;
        if ((obj == null) || !(obj instanceof User)) return false;
        User q1 = (User) obj;
        if (this.Name.equals(q1.getName())) return true;
        return false;
    }
    public Set<String> getTitles(){
        return Scores.keySet();
    }
    @NonNull
    @Override
    public String toString() {
        StringBuilder text  = new StringBuilder(Name);
        text.append(":");
        text.append("\n");
        for(String i:Scores.keySet()) {
            text.append(i);
            text.append(": ");
            text.append("\n\t");
            for(String j:Scores.get(i).keySet()){
                text.append(j);
                text.append(": ");
                text.append(Scores.get(j));
                text.append("\n\t");}
        }
        return text.toString();

    }
}

